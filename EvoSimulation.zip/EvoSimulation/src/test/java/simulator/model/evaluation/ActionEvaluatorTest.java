package simulator.model.evaluation;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ActionEvaluatorTest {

	@Test
	void testEvaluateMapOfStringObject() {
		ActionEvaluator eval = new ActionEvaluator();
		fail("Not yet implemented");
	}

}
