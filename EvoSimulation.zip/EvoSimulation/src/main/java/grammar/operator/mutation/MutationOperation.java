package grammar.operator.mutation;

import simulator.model.entity.individuals.Genotype;

public abstract class MutationOperation {
	public abstract void mutate(Genotype g);

}
