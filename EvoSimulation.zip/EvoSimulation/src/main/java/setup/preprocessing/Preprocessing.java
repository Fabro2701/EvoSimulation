package setup.preprocessing;

public interface Preprocessing {
	public static String apply(String input) {
		System.err.println("not implemented");
		return null;
	}
}
