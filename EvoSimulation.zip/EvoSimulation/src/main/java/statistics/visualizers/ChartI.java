package statistics.visualizers;

public interface ChartI {

}
