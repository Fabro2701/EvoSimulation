package simulator.model.evaluation;

public class EvaluationException extends Exception{
	public EvaluationException(String msg) {
		super(msg);
	}
}
