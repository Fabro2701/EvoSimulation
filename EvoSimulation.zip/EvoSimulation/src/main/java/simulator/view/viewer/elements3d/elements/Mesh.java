package simulator.view.viewer.elements3d.elements;

import java.util.List;

public class Mesh {
	public List<Triangle>triangles;

	public List<Triangle> getTriangles() {
		return triangles;
	}

	public void setTriangles(List<Triangle> triangles) {
		this.triangles = triangles;
	}
}
