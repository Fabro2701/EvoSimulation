package simulator.control.fsm;

public class Input {

}
