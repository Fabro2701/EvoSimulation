package test;

public interface TestI {

}
