package test;

public enum AAA implements TestI{
	A1,A2;
}
